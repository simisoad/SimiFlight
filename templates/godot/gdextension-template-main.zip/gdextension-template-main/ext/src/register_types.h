#ifndef ST_REGISTER_TYPES_H
#define ST_REGISTER_TYPES_H

void initialize_module();
void uninitialize_module();

#endif // ST_REGISTER_TYPES_H