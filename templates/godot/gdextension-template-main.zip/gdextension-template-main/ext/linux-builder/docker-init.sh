#!/bin/sh

# Build the Docker image
docker build -t st_linux_builder .
