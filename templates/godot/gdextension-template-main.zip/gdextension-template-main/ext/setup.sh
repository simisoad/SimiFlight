#!/bin/bash

# This will download the godot-cpp repo and add it as a submodule in the correct location
git submodule add https://github.com/godotengine/godot-cpp.git ./godot-cpp
