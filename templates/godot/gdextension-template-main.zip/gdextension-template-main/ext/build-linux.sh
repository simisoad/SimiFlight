cd ./linux-builder
./build-linux.sh
